<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package Monotheme
 */

get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<section class="slider" id="home">
				<div class="container-fluid">
					<div class="row">

					    <div id="carouselHacked" class="carousel slide carousel-fade" data-ride="carousel">
							<div class="header-backup"></div>
					        <!-- Wrapper for slides -->
					        <div class="carousel-inner" role="listbox">
					            <div class="item active">
					            	<img src="<?php echo(get_template_directory_uri()); ?>/img/slide-one.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Tax</h1>
				               			<p>good business consulting service</p>
				               			<button>learn more</button>
					                </div>
					            </div>
					            <div class="item">
					            	<img src="<?php echo(get_template_directory_uri()); ?>/img/slide-two.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Financial</h1>
				               			<p>good business consulting service</p>
				               			<button>learn more</button>
					                </div>
					            </div>
					            <div class="item">
					            	<img src="<?php echo(get_template_directory_uri()); ?>/img/slide-three.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Consulting</h1>
				               			<p>good business consulting service</p>
				               			<button>learn more</button>
					                </div>
					            </div>
					            <div class="item">
					            	<img src="<?php echo(get_template_directory_uri()); ?>/img/slide-four.jpg" alt="">
					                <div class="carousel-caption">
				               			<h1>Money</h1>
				               			<p>good business consulting service</p>
				               			<button>learn more</button>
					                </div>
					            </div>
					        </div>

					        <!-- Controls -->
					        <a class="left carousel-control" href="#carouselHacked" role="button" data-slide="prev">
					            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
					            <span class="sr-only">Previous</span>
					        </a>
					        <a class="right carousel-control" href="#carouselHacked" role="button" data-slide="next">
					            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
					            <span class="sr-only">Next</span>
					        </a>
					    </div>

					</div>
				</div>
			</section><!-- end of slider section -->



		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
